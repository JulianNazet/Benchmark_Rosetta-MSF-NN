import argparse
import keras
import numpy
import pandas
import os
import random
import sys

parser = argparse.ArgumentParser(description='Generates NeuralNetwork')
parser.add_argument('-data',required=True,help='Path to inputdata')
parser.add_argument('-encoding',required=True,help='Patch to feature.csv')
parser.add_argument('-seed',required=False,default='best',type=str,help='Seed sequence for NN. Default: current best scoring')
parser.add_argument('-pool',required=False,default='RHKDECGPSTNQAVILMFYW',type=str,help='Amino acids to use. Default: RHKDECGPSTNQAVILMFYW')
parser.add_argument('-NN_pop',required=False,default=2000000,type=int,help='How many Sequences to test with NN. Default: 2000000')
parser.add_argument('-fitness',required=False,default='all_plus',type=str,help='Path to Fitness.daf. Default: Total Sum')
parser.add_argument('-new_seqs',required=True,type=int,help='How many new sequences to write')
args=parser.parse_args()

os.chdir(os.path.abspath(os.path.dirname(args.data)))

def gen_data(Encoding_Dic):
    Temp = pandas.read_csv(os.path.abspath(args.data),header=None)
    Used_seq = []
    Total_energy = []
    for i in range(len(Temp)):
        Tempseq = []
        feature = []
        energy = []
        for item in Temp.iloc[i,:]:
            if type(item) == str:
                Tempseq.append(item)
                feature.extend(Encoding_Dic[item])
            else:
                energy.append(float(item))
        if i == 0:
            X = pandas.DataFrame(index=range(Temp.shape[0]),columns=range(len(feature)))
            Multistate = 0
            if len(energy) > 1:
                Multistate = 1
            Y = pandas.DataFrame(index=range(Temp.shape[0]),columns=range(len(energy)-Multistate))
        X.iloc[i,:] = feature
        Y.iloc[i,:] = energy[Multistate:]
        Total_energy.append(energy[0])
        Used_seq.append(Tempseq)
    best = numpy.argmin(Total_energy)
    Tempseed  = ''.join(Used_seq[best])
    return(X,Y,Used_seq,Tempseed)

def random_seq(Seed,AA_pool,Encoding_Dic):
    AA_pool = list(AA_pool)
    Seed = list(Seed)
    Sequences = []
    Raw_sequences = []
    print('Building random')
    Total = args.NN_pop
    for i in range(int(Total)):
        Positions = list(range(len(Seed)))
        random.shuffle(Positions)
        Positions = Positions[0:random.randint(1,len(Seed)-1)]
        Tempsequence = Seed[:]
        for Position in Positions:
            Tempsequence[Position] = AA_pool[random.randint(0,len(AA_pool)-1)]
        Raw_sequences.append(Tempsequence)
        Sequence = []
        for AA in Tempsequence:
            Sequence.extend(Encoding_Dic[AA])
        Sequences.append(Sequence)
    Sequences = pandas.DataFrame(Sequences)
    return(Sequences,Raw_sequences)

def get_fitness():
    with open(os.path.abspath(args.fitness),'r') as fitness_func:
        content = fitness_func.readlines()

    fitnessline = content[-2]
    fitnessline = fitnessline.strip('\n').split('=')[-1].split(' ')
    Operators = []
    Factors = []
    for i, item in enumerate(fitnessline):
        if 'state' in item:
            continue
        if '*' in item:
            Factors.append(float(fitnessline[i-1]))
            Operators.append(item)
        if '+' in item or '-' in item:
            Operators.append(item)
    return(Operators,Factors)

def main():
    def Neural_Network(i):
        Y_state = Y.iloc[:,i]
        model = keras.Sequential()
        Neurons_1 = 10 + int(X.shape[1]/2)
        model.add(keras.layers.Dense(Neurons_1,input_shape=(X.shape[1],),activation='tanh',kernel_initializer='RandomNormal',use_bias=0))
        Neurons_2 = 5 + int(X.shape[1]/4)
        model.add(keras.layers.Dense(Neurons_2,activation='tanh',kernel_initializer='RandomNormal',use_bias=0))
        model.add(keras.layers.Dense(1,activation='linear',kernel_initializer='RandomNormal',use_bias=0))
        epochen = 100
        sgd = keras.optimizers.SGD(lr = 0.1,momentum = 0.8, decay=0.1/(epochen*X.shape[0]),nesterov=False)
        model.compile(loss='mse',optimizer='sgd')
        history = model.fit(X,Y_state,epochs = epochen,validation_split=0.01,batch_size=1)
        return(model)

    #generate encoding dic
    with open(os.path.abspath(args.encoding)) as file_h:
        content = file_h.readlines()
    content = [x.strip() for x in content]
    Encoding_Dic = {}
    Decoding_Dic = {}
    for line in content:
        line = line.split(',')
        features = [float(i) for i in line[1:]]
        Encoding_Dic[line[0]] = features

    #generte Data, all used sequences and the current best seed
    X, Y, Used_seq, Tempseed = gen_data(Encoding_Dic)

    #Seed
    if args.seed == 'best':
        seed = Tempseed
    else:
        seed = args.seed

    #generate fitness
    if args.fitness == 'all_plus':
        Operators = ['+' for i in range(Y.shape[1])]
    else:
        Operators, Factors = get_fitness()

    #Normalizing
    print('Normalizing')
    X = X.apply(lambda a : a / 100)

    for i in range(Y.shape[1]):
        Mean_Y = numpy.mean(Y.iloc[:,i])
        Std_Y = numpy.std(Y.iloc[:,i])
        Y.iloc[:,i] = (Y.iloc[:,i] - Mean_Y) / Std_Y

    #generate Model
    Models = []
    for i in range(Y.shape[1]):
        Models.append(Neural_Network(i))

    #Generating new Sequences
    To_write = []
    Sequences, Raw_sequences = random_seq(seed,args.pool,Encoding_Dic)

    #predict
    operator = 0
    factor = 0
    Y_predicted_total = 0
    for m, model in enumerate(Models):
        Y_predicted = model.predict(X)
        Y_predicted = Y_predicted.reshape(Y_predicted.shape[0]).reshape(Y_predicted.shape[0])
        if Operators[operator] == '*':
            Y_predicted = Y_predicted * Factors[factor]
            factor += 1
            operator += 1
        if Operators[operator] == '+':
            Y_predicted_total = Y_predicted_total + Y_predicted
            operator += 1
        elif Operators[operator] == '-':
            Y_predicted_total = Y_predicted_total - Y_predicted
            operator += 1
        else:
            sys.exit('UNKNOWN FITNESS OPERATOR')

    sorter = numpy.argsort(Y_predicted_total)

    for idx in sorter:
        if Raw_sequences[idx] not in Used_seq:
            To_write.append(Raw_sequences[idx])
            Used_seq.append(Raw_sequences[idx])
        if len(To_write) == args.new_seqs:
            break

    with open('NN_Output.csv','w') as outfile:
        for line in To_write:
            outfile.write(','.join(line) + '\n')

if __name__ == '__main__':
    main()
